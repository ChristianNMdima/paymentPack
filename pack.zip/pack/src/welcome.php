<h1>Welcome</h1>
<p>
    <a href="?page=login"><button class="btn btn-primary">Login</button></a>
    <a href="?page=register"><button class="btn btn-primary">Register</button></a>
</p>