<div class="alert success">
    welcome <?php echo $_SESSION['name']; ?>
</div>