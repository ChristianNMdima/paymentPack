<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="form.css" type="text/css">

<head>
    <meta charset="UTF-8">
    <meta name="author" content= "sahil kumar">
    <meta http-equiv="X-UA-Compatible" content=" content="ie=EDGE">
    <META NAME="VIEWPORT" content="width=device-width, initial-scale=1,
    shrink-to-fit=no">
    <title>Transactions</title>

        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <!-- Popper JS -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>

<body>
    <nav class="navbar navbar-expand-md bg-dark navbar-dark">
        <!-- Brand -->
        <a class="navbar-brand" href="#">TRANSACTIONS</a>
        <!-- Toggler/collapsibe Button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav"> 
    <li class="nav-item">
        <a class="nav-link" href="home.php">Home</a>
      </li> 
    <li class="nav-item">
        <a class="nav-link" href="RequIsitions.php">Capture Requisition</a>
      </li> 
      <li class="nav-item">
        <a class="nav-link" href="#">Authorise Requistion</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="ReceiptReq.php">Receive Requisition</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="#">Authorise Payment</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="welcome.html">Exit</a>
      </li> 
    
    </ul>
</div>
    <form class="form-inline" action="/action_page.php">
        <input class="form-control mr-sm-2" type="text" placeholder="Search">
        <button class="btn btn-primary" type="submit">Search</button>
  </form>
  </nav>

  </div>
  <button type="button" onclick> href="requisitions.php>requisitions</button>  
  <button type="button" onclick="alert('Hello world!')">Click Me!</button>
  <button type="button" onclick="alert('Hello world!')">Click Me!</button>
           
           <div class="footer">
         
          

    </div>
</form>
</div>
</body>
</html>
